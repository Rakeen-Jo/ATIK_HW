java -jar RoboSim-v-2.0.0.jar
@pause